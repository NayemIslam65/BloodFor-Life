<?php

  include "header.php";

  include "lib/connection.php";
    if(isset($_POST['loginsubmit'])){
    $uemail=$_POST['email'];
    $password=$_POST['password'];
    
    $sql="SELECT * FROM admin WHERE email='".$uemail."' AND pass='".$password."' limit 1";
    $result=$conn->query($sql);

    if($result->num_rows==1){
    header("Location:admin.php");
    }
    else{
        echo "Incorrect Email or Password Entered";
        exit();
    }
}



?>
    
        <!--    form starts   -->
<div class="container-contact100">

		<div class="wrap-contact100">
			<form action="" class="contact100-form validate-form" method="post">
				<span class="contact100-form-title bedonortitle">
					sign in to admin account
				</span>

				<div class="wrap-input100 validate-input" data-validate = "Please enter your email: e@a.x">
					<input class="input100" type="text" name="email" placeholder="EMAIL">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "Please enter your phone">
					<input class="input100" type="password" name="password" placeholder="PASSWORD">
					<span class="focus-input100"></span>
				</div>

			
				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn" name="loginsubmit">
						<span>
							<i class="fa fa-paper-plane-o m-r-6" aria-hidden="true"></i>
							Send
						</span>
					</button>
				</div>
			</form>
		</div>
	</div>
     
        <!--    form ends   -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/app.js"></script>
</body>

</html>

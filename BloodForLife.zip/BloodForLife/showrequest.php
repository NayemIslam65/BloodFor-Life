<?php 
    
    include "lib/connect.php";

    //select query
    $select_sql="SELECT * FROM request";
    $select_query=$conn->query($select_sql);

    include "header.php";

?>

    
        <!--    banner part starts   -->
    <div class="col-md-12 banner">
    <span id="info1">All Requests</span>
	<div id="info" class="col-md-12">
           
    <!--=====================
          Content
======================-->
        <section id="content">
            <div class="table table-dark">
                <table border="1" width=100%;>
                    <tr>
                        <th>Name</th>
                        <th>Blood Group</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Location</th>
<!--                        <th>Phone Number</th>-->
<!--                        <th>Action</th>-->
                    </tr>
                    <?php   if($select_query->num_rows>0){         ?>
                    <?php while($data=$select_query->fetch_assoc()){ ?>
                    <tr>
                        <th>
                            <?php echo $data['name'] ?>
                        </th>
                        <th>
                            <?php echo $data['bloodgroup'] ?>
                        </th>
                        <th>
                            <?php echo $data['mail'] ?>
                        </th>
                        <th>
                            <?php echo $data['phone_num'] ?>
                        </th>
                        <th>
                            <?php echo $data['location'] ?>
                        </th>
<!--
                        <th>
                         
                        </th>
-->
<!--
                        <td>
                            <a href="lib/edit.php?id=<?php  echo $data['id']; ?>">Edit</a>
                            <a href="lib/delete.php?id=<?php echo $data['id'];  ?>">Delete</a>
                        </td>
-->
                    </tr>

                    <?php } ?>
                    <?php } else{  ?>
                    <tr>
                        <td colspan="6">No Records Found!</td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </section>
	</div>
      
       </div>
        
        
        <!--    banner part ends   -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/app.js"></script>
</body>

</html>

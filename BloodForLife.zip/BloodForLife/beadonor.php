<?php 
    
    include "lib/connection.php";
    $result="";
 //insert query
    if(isset($_POST['add_data'])){
        $full_name= $_POST['full_name'];
        $blood_group= $_POST['blood_group'];
        $email= $_POST['email'];
        $pass= $_POST['pass'];
        $conn_pass=$_POST['conn_pass'];
        $phone= $_POST['phone'];
        $address= $_POST['address'];
        
        
        
//        if($pass==$conn_pass){
        $insert_sql = "INSERT INTO donor (full_name,blood_group,email,pass,phone,address) values ('$full_name', '$blood_group', '$email','$pass',$phone,'$address')";
        
        if($conn->query($insert_sql)){
            $result = "Successfully Submitted!";
        }
        else{
            die($conn->error);
        }
//        }
//
//       else{
//            $result= "Password did not match! Try again";       }
    }

       //select query
    
    $select_sql="SELECT * FROM donor";
    $select_query=$conn->query($select_sql);

    include "header.php";

?>


    <!--    form starts   -->
    <div class="container-contact100">

        <div class="wrap-contact100">
            <form autocomplete="off" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="contact100-form validate-form" method="post">
                <span class="contact100-form-title bedonortitle">
                    Be a Donor & Save others Life
                </span>

                <div class="wrap-input100 validate-input" data-validate="Please enter your name">
                    <input class="input100" type="text" name="full_name" placeholder="Full Name" required>
                    <span class="focus-input100"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Please enter your Blood Group">
                    <input class="input100" type="text" name="blood_group" placeholder="Blood Group" required>
                    <span class="focus-input100"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Please enter your email: e@a.x">
                    <input class="input100" type="email" name="email" placeholder="E-mail" required>
                    <span class="focus-input100"></span>
                </div>
                
                <div class="wrap-input100 validate-input" data-validate = "Please enter your phone">
					<input class="input100" type="password" name="pass" id="password" placeholder="Password" required>
					<span class="focus-input100"></span>
				</div>
               
                <div class="wrap-input100 validate-input" data-validate = "Please enter your phone">
					<input class="input100" type="password" name="conn_pass" id="password2" placeholder="Re-enter Password" onKeyUp="checkPass(); return false;" required>
					<span class="focus-input100"></span>
				</div>
                <div>
                    <span id="confirmMessage" class="confirmMessage"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Please enter your phone">
                    <input class="input100" type="number" name="phone" placeholder="Phone" required>
                    <span class="focus-input100"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Please enter your Address">
                    <textarea class="input100" name="address" placeholder="Full Address. eg: Block: D , Bashundhara R/A , Dhaka. " required></textarea>
                    <span class="focus-input100"></span>
                </div>

<!--
                <div class="bedonorradio">
                   <label for="">Did you ever donate blood before?</label>
                    <input type="radio" name="demo" value="one" id="radio-one" class="form-radio"><label for="radio-one">Yes</label>
                    <input type="radio" name="demo" value="one" id="radio-one" class="form-radio"><label for="radio-one">No</label>


                </div>
-->

                <div class="container-contact100-form-btn">
                    <button name="add_data" value="Send" class="contact100-form-btn">
                        <span>
                            <i class="fa fa-paper-plane-o m-r-6" aria-hidden="true"></i>
                            Send
                        </span>
                    </button>
</div>  
                 <div class="result" style="text-align:center">
            <?php echo $result; ?> 
                </div>
            </form>
        </div>
    </div>
    
            

    <!--    form ends   -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/app.js"></script>
</body>

</html>

<?php 
    
    include "lib/connection.php";
    $result="";
 //insert query
    if(isset($_POST['add_data'])){
        $rfull_name= $_POST['rname'];
        $remail= $_POST['remail'];
        $rphone= $_POST['rphone'];
        $raddress= $_POST['raddress'];
        
        
        
//        if($pass==$conn_pass){
        $insert_sql = "INSERT INTO message (name,mail,phone_num,message) values ('$rfull_name', '$remail',$rphone,'$raddress')";
        
        if($conn->query($insert_sql)){
            $result = "Successfully Submitted!";
        }
        else{
            die($conn->error);
        }
//        }
//
//       else{
//            $result= "Password did not match! Try again";       }
    }

       //select query
    
    $select_sql="SELECT * FROM donor";
    $select_query=$conn->query($select_sql);

    include "header.php";

?>

    <!--    form starts   -->
    <div class="container-contact100">

        <div class="wrap-contact100">
            <form autocomplete="off" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="contact100-form validate-form" method="post">
                <span class="contact100-form-title bedonortitle">
                    Message Admin Here
                </span>

                <div class="wrap-input100 validate-input" data-validate="Please enter your name">
                    <input class="input100" type="text" name="rname" placeholder="Name" required>
                    <span class="focus-input100"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Please enter your email: e@a.x">
                    <input class="input100" type="text" name="remail" placeholder="E-mail" required>
                    <span class="focus-input100"></span>
                </div>
                
          
                <div class="wrap-input100 validate-input" data-validate="Please enter your phone">
                    <input class="input100" type="number" name="rphone" placeholder="Phone" required>
                    <span class="focus-input100"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Please enter your Address">
                    <textarea class="input100" name="raddress" placeholder="Message Here" required></textarea>
                    <span class="focus-input100"></span>
                </div>

                <div class="container-contact100-form-btn">
                    <button name="add_data" value="Send" class="contact100-form-btn">
                        <span>
                            <i class="fa fa-paper-plane-o m-r-6" aria-hidden="true"></i>
                            Send
                        </span>
                    </button>
                </div>  
                
                 <div class="result" style="text-align:center">
            <?php echo $result; ?> 
                </div>
            </form>
        </div>
    </div>
    
            

    <!--    form ends   -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/app.js"></script>
</body>

</html>
